package stepdefs;

import java.io.IOException;
import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import applicationPages.Assignmentpage;
import io.cucumber.core.api.Scenario;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.BeforeStep;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import webconnector.Webconnector;

public class AssignmentPageSteps extends Webconnector {
	private Assignmentpage assignmentpage;
	private String scenDesc;
	private List<QuestionsDataTable> dt;

	public AssignmentPageSteps() {
		this.assignmentpage = new Assignmentpage();
	}

	@Before
	public void before(Scenario scenario) throws InvalidFormatException, IOException {
		this.scenDesc = scenario.getName();
		String URL=Webconnector.getSpecificColumnData("./src/test/testdata/data.xlsx","sheet1", "URL");
		setUpDriver(URL);
	}

	@After
	public void after(Scenario scenario){
		closeDriver(scenario);
	}

	@BeforeStep
	public void beforeStep() throws InterruptedException {
		Thread.sleep(2000);
	}

	/* Step definitions for Background: Validation of Assignment Page webElements displayed*/
	@Then("^User validates different UI fields present in the page$")
	public void validatesFields() throws Exception {
		this.assignmentpage.validatesFieldsDisplayed();
	}

	/*Step definitions for Scenario: Validation of create question button functionality*/
	@Given("User enter the details")
	public void enterDetailsForCreatingQWuestion(List<QuestionsDataTable> dt) throws InvalidFormatException, IOException {
		this.dt=dt;
		for(QuestionsDataTable criteria:dt)
		{
			this.assignmentpage.detailsForCreatingQuestion(criteria.getQuestion(), criteria.getAnswer());
			this.assignmentpage.validationOfClicksOnCreateQuestionButton();
		}
	}

	public void clicksOnCreateQuestionButton() throws Exception {
		this.assignmentpage.validationOfClicksOnCreateQuestionButton();
	}

	@Then("^User validates all the questions additions in the UI$")
	public void allTheQuestionsAdditions() throws Exception {
		this.assignmentpage.validationOfAllTheQuestionsAdditions();
	}

	/* Step definitions for Scenario: Validation of Sort questions button functionality*/
	@Then("^User clicks on Sort questions button$")
	public void userClickOnSortQuestionsButton() throws InvalidFormatException, IOException {
		this.assignmentpage.clickOnSortQuestionsButton();
	}

	@And("^User validates the sorted questions result$")
	public void validatesSortedQuestionsResult() throws Exception {
		this.assignmentpage.validationOfSortQuestions();
	}

	/* Step definitions for Scenario: Validation of Remove questions button functionality*/
	@Then("^User clicks on Remove questions button$")
	public void userClickOnRemoveQuestionsButton() throws InvalidFormatException, IOException {
		this.assignmentpage.clickOnRemoveQuestionsButton();
	}

	@And("^User validates the Remove questions result$")
	public void validatesRemoveQuestionsResult() throws Exception {
		this.assignmentpage.validationOfRemoveQuestions();
	}
}
