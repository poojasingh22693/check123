package applicationPages;

import java.util.List;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import methods.SeleniumHelper;
import webconnector.Webconnector;

public class Assignmentpage extends Webconnector {

	SeleniumHelper sh=new SeleniumHelper();
	Logger logger = Logger.getLogger(Assignmentpage.class.getName());

	public WebDriver getDriver() {
		return driver;
	}
	/*Locators for the Assignment page */
	public static final By MAIN_PAGE_HEADER = By.xpath("//h1[contains(text(),'The awesome Q/A tool')]");
	public static final By SIDEBAR_TEXT = By.xpath("//div[contains(text(),'Here you can find ')]");
	public static final By CREATED_QUESTIONS_HEADER =By.xpath("//h2[contains(text(),'Created questions')]");
	public static final By CREATE_A_NEW_QUESTION_HEADER = By.xpath("//h2[contains(text(),'Create a new question')]");
	public static final By SORT_QUESTIONS_BUTTON = By.xpath("//button[contains(text(),'Sort questions')]");
	public static final By REMOVE_QUESTIONS_BUTTON = By.xpath("//button[contains(text(),'Remove questions')]");
	public static final By CREATE_QUESTION_BUTTON = By.xpath("//button[contains(text(),'Create question')]");
	public static final By CREATE_QUESTION_FIELD =By.id("question");
	public static final By CREATE_ANSWER_FIELD =By.id("answer");
	public static final By CREATED_QUESTION_ANSWER_LIST = By.className("list-group-item question");
	public static final By CREATED_QUESTION = By.className("question__question");
	public static final By CREATED_ANSWER = By.className("question__answer hidden-xl-down");
	public static final By NO_QUESTIONS_MESSAGE = By.xpath("//div[text()='No questions yet :-(']");

	/* Implementations for Background: Validation of Assignment Page webElements displayed*/
	public void validatesFieldsDisplayed() {

		logger.info( driver.getCurrentUrl());
		logger.info( driver.getWindowHandle());
		SoftAssert sa=new SoftAssert();
		sa.assertTrue(driver.getCurrentUrl().contains("http://localhost:8000/"), "The required Url is not yet launched");
		sa.assertTrue(sh.isElementVisible(MAIN_PAGE_HEADER), "The MAIN_PAGE_HEADER webElement is not present in the page");
		sa.assertTrue(sh.isElementVisible(SIDEBAR_TEXT), "The SIDEBAR_TEXT webElement is not present in the page");
		sa.assertTrue(sh.isElementVisible(CREATED_QUESTIONS_HEADER), "The CREATED_QUESTIONS_HEADER webElement is not present in the page");
		sa.assertTrue(sh.isElementVisible(CREATE_A_NEW_QUESTION_HEADER), "The CREATE_A_NEW_QUESTION_HEADER webElement is not present in the page");
		sa.assertTrue(sh.isElementVisible(SORT_QUESTIONS_BUTTON), "The SORT_QUESTIONS_BUTTON webElement is not present in the page");
		sa.assertTrue(sh.isElementVisible(REMOVE_QUESTIONS_BUTTON), "The REMOVE_QUESTIONS_BUTTON webElement is not present in the page");
		sa.assertTrue(sh.isElementVisible(CREATE_QUESTION_BUTTON), "The CREATE_QUESTION_BUTTON webElement is not present in the page");
		sa.assertAll();
	}

	/*Implementations for Scenario: Validation of create question button functionality*/
	public void	detailsForCreatingQuestion(String question, String answer) {
		
		driver.findElement(CREATE_QUESTION_FIELD).sendKeys(question);
		driver.findElement(CREATE_ANSWER_FIELD).sendKeys(answer);	
	}

	public void validationOfClicksOnCreateQuestionButton() {

		driver.findElement(CREATE_QUESTION_BUTTON).click();
	}

	public void validationOfAllTheQuestionsAdditions() {

		SoftAssert sa=new SoftAssert();
		List<WebElement> all_questions_answers_List=driver.findElements(CREATED_QUESTION_ANSWER_LIST);
		sa.assertTrue(all_questions_answers_List.size()>1, "The questions and Answers List are not shown in the list");
		List<WebElement> all_questions_List=driver.findElements(CREATED_QUESTION);
		sa.assertTrue(all_questions_List.size()>1, "The questions are not shown in the list");
		List<WebElement> all_answers_List=driver.findElements(CREATED_ANSWER);
		sa.assertTrue(all_answers_List.size()>1, "The answers are not shown in the list");
		sa.assertAll();
	}

	/* Implementations for Scenario: Validation of Sort questions button functionality*/
	public void clickOnSortQuestionsButton() {

		driver.findElement(SORT_QUESTIONS_BUTTON).click();
	}

	public void validationOfSortQuestions() {

		List<WebElement> all_questions_List=driver.findElements(CREATED_QUESTION);	
		List<WebElement> sorted_List = all_questions_List.stream().sorted().collect(Collectors.toList());
		Assert.assertEquals(all_questions_List, sorted_List, "The questions are not sorted as expected");
	}

	/* Implementations for Scenario: Validation of Remove questions button functionality*/
	public void clickOnRemoveQuestionsButton(){

		driver.findElement(REMOVE_QUESTIONS_BUTTON).click();
	}

	public void validationOfRemoveQuestions(){

		Assert.assertTrue(sh.isElementVisible(NO_QUESTIONS_MESSAGE), "The NO_QUESTIONS_MESSAGE is not present in the page");
	}

}