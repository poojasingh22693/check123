package constantVariables;
public class Constant {
	public static final String glue = "stepdefs";
	public static final String tags = "@blog_page";

}
