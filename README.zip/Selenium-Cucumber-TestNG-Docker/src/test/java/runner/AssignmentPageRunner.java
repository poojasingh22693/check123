package runner;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import io.cucumber.testng.CucumberOptions;


@CucumberOptions( tags = {"@assignment_page"},glue = {"stepdefs"}, plugin = {"html:target/cucumber-reports/AssignmentPage/cucumber-pretty","json:target/json-cucumber-reports/assignmentpage/cukejson.json",
		"testng:target/testng-cucumber-reports/AssignmentPage/cuketestng.xml" }, features = {"src/test/resources/features/AssignmentPage"})
public class AssignmentPageRunner extends AbstractTestNGCucumberParallelTests {
	
	@BeforeClass
	public static void before() {
		System.out.println("Before - "+System.currentTimeMillis());
	}
	
	@AfterClass
	public static void after() {
		System.out.println("After - "+System.currentTimeMillis());
	}

}
